﻿
namespace _1.Mobile_Shop_Management_System.All_User_Control
{
    partial class Add_other_Accessories
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Add_other_Accessories));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txttemplate = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtbackcover = new Guna.UI2.WinForms.Guna2TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.label5 = new System.Windows.Forms.Label();
            this.bthadd = new System.Windows.Forms.Button();
            this.txtphonecharger = new Guna.UI2.WinForms.Guna2TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            this.btnrest = new System.Windows.Forms.Button();
            this.btnshow = new System.Windows.Forms.Button();
            this.txtcid = new Guna.UI2.WinForms.Guna2TextBox();
            this.lblcid = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 25.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.label1.Location = new System.Drawing.Point(84, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(641, 53);
            this.label1.TabIndex = 0;
            this.label1.Text = "Another Category  Item Add  ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(151, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Template Name";
            // 
            // txttemplate
            // 
            this.txttemplate.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txttemplate.DefaultText = "";
            this.txttemplate.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txttemplate.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txttemplate.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txttemplate.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txttemplate.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txttemplate.Font = new System.Drawing.Font("Segoe UI", 10.2F);
            this.txttemplate.ForeColor = System.Drawing.Color.Black;
            this.txttemplate.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txttemplate.Location = new System.Drawing.Point(4, 137);
            this.txttemplate.Margin = new System.Windows.Forms.Padding(4);
            this.txttemplate.Name = "txttemplate";
            this.txttemplate.PasswordChar = '\0';
            this.txttemplate.PlaceholderText = "";
            this.txttemplate.SelectedText = "";
            this.txttemplate.Size = new System.Drawing.Size(395, 46);
            this.txttemplate.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txttemplate.TabIndex = 4;
            // 
            // txtbackcover
            // 
            this.txtbackcover.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbackcover.DefaultText = "";
            this.txtbackcover.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtbackcover.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtbackcover.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtbackcover.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtbackcover.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtbackcover.Font = new System.Drawing.Font("Segoe UI", 10.2F);
            this.txtbackcover.ForeColor = System.Drawing.Color.Black;
            this.txtbackcover.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtbackcover.Location = new System.Drawing.Point(4, 382);
            this.txtbackcover.Margin = new System.Windows.Forms.Padding(4);
            this.txtbackcover.Name = "txtbackcover";
            this.txtbackcover.PasswordChar = '\0';
            this.txtbackcover.PlaceholderText = "";
            this.txtbackcover.SelectedText = "";
            this.txtbackcover.Size = new System.Drawing.Size(395, 46);
            this.txtbackcover.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txtbackcover.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 324);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(166, 25);
            this.label3.TabIndex = 5;
            this.label3.Text = "Back cover Name";
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 26;
            this.guna2Elipse1.TargetControl = this;
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(504, 157);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersWidth = 51;
            this.dataGridView3.RowTemplate.Height = 24;
            this.dataGridView3.Size = new System.Drawing.Size(577, 466);
            this.dataGridView3.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold);
            this.label5.Image = ((System.Drawing.Image)(resources.GetObject("label5.Image")));
            this.label5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label5.Location = new System.Drawing.Point(497, 88);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(261, 54);
            this.label5.TabIndex = 13;
            this.label5.Text = "Accessories ";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bthadd
            // 
            this.bthadd.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold);
            this.bthadd.Location = new System.Drawing.Point(892, 629);
            this.bthadd.Name = "bthadd";
            this.bthadd.Size = new System.Drawing.Size(189, 52);
            this.bthadd.TabIndex = 14;
            this.bthadd.Text = "Add";
            this.bthadd.UseVisualStyleBackColor = true;
            this.bthadd.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtphonecharger
            // 
            this.txtphonecharger.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtphonecharger.DefaultText = "";
            this.txtphonecharger.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtphonecharger.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtphonecharger.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtphonecharger.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtphonecharger.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtphonecharger.Font = new System.Drawing.Font("Segoe UI", 10.2F);
            this.txtphonecharger.ForeColor = System.Drawing.Color.Black;
            this.txtphonecharger.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtphonecharger.Location = new System.Drawing.Point(4, 247);
            this.txtphonecharger.Margin = new System.Windows.Forms.Padding(4);
            this.txtphonecharger.Name = "txtphonecharger";
            this.txtphonecharger.PasswordChar = '\0';
            this.txtphonecharger.PlaceholderText = "";
            this.txtphonecharger.SelectedText = "";
            this.txtphonecharger.Size = new System.Drawing.Size(395, 46);
            this.txtphonecharger.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txtphonecharger.TabIndex = 16;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(3, 210);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(145, 25);
            this.label6.TabIndex = 15;
            this.label6.Text = "Phone charger ";
            // 
            // btnupdate
            // 
            this.btnupdate.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold);
            this.btnupdate.Location = new System.Drawing.Point(697, 630);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(189, 52);
            this.btnupdate.TabIndex = 17;
            this.btnupdate.Text = "Update ";
            this.btnupdate.UseVisualStyleBackColor = true;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // btndelete
            // 
            this.btndelete.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold);
            this.btndelete.Location = new System.Drawing.Point(502, 630);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(189, 52);
            this.btndelete.TabIndex = 18;
            this.btndelete.Text = "Delete ";
            this.btndelete.UseVisualStyleBackColor = true;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // btnrest
            // 
            this.btnrest.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold);
            this.btnrest.Location = new System.Drawing.Point(0, 630);
            this.btnrest.Name = "btnrest";
            this.btnrest.Size = new System.Drawing.Size(189, 52);
            this.btnrest.TabIndex = 19;
            this.btnrest.Text = "Rset";
            this.btnrest.UseVisualStyleBackColor = true;
            this.btnrest.Click += new System.EventHandler(this.btnrest_Click);
            // 
            // btnshow
            // 
            this.btnshow.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold);
            this.btnshow.Location = new System.Drawing.Point(834, 96);
            this.btnshow.Name = "btnshow";
            this.btnshow.Size = new System.Drawing.Size(243, 48);
            this.btnshow.TabIndex = 37;
            this.btnshow.Text = "Show Accessories ";
            this.btnshow.UseVisualStyleBackColor = true;
            this.btnshow.Click += new System.EventHandler(this.btnshow_Click);
            // 
            // txtcid
            // 
            this.txtcid.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtcid.DefaultText = "";
            this.txtcid.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtcid.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtcid.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtcid.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtcid.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtcid.Font = new System.Drawing.Font("Segoe UI", 10.2F);
            this.txtcid.ForeColor = System.Drawing.Color.Black;
            this.txtcid.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtcid.Location = new System.Drawing.Point(4, 490);
            this.txtcid.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtcid.Name = "txtcid";
            this.txtcid.PasswordChar = '\0';
            this.txtcid.PlaceholderText = "";
            this.txtcid.SelectedText = "";
            this.txtcid.Size = new System.Drawing.Size(60, 53);
            this.txtcid.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txtcid.TabIndex = 40;
            // 
            // lblcid
            // 
            this.lblcid.AutoSize = true;
            this.lblcid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcid.ForeColor = System.Drawing.Color.Black;
            this.lblcid.Location = new System.Drawing.Point(-1, 445);
            this.lblcid.Name = "lblcid";
            this.lblcid.Size = new System.Drawing.Size(89, 25);
            this.lblcid.TabIndex = 39;
            this.lblcid.Text = "Enter nid";
            // 
            // Add_other_Accessories
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.txtcid);
            this.Controls.Add(this.lblcid);
            this.Controls.Add(this.btnshow);
            this.Controls.Add(this.btnrest);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.txtphonecharger);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.bthadd);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.txtbackcover);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txttemplate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Add_other_Accessories";
            this.Size = new System.Drawing.Size(1116, 779);
            this.Load += new System.EventHandler(this.Add_other_Accessories_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2TextBox txttemplate;
        private Guna.UI2.WinForms.Guna2TextBox txtbackcover;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button bthadd;
        private Guna.UI2.WinForms.Guna2TextBox txtphonecharger;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Button btnrest;
        private System.Windows.Forms.Button btnshow;
        private Guna.UI2.WinForms.Guna2TextBox txtcid;
        private System.Windows.Forms.Label lblcid;
    }
}
