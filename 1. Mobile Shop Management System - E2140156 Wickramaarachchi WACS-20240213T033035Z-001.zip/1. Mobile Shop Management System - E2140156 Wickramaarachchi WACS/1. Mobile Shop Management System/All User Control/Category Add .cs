﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace _1.Mobile_Shop_Management_System.All_User_Control
{
    public partial class Add_other_Accessories : UserControl
    {
        public Add_other_Accessories()
        {
            InitializeComponent();
        }

   
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string template = txttemplate.Text;
                string backcover = txtbackcover.Text;
                string phonecharger = txtphonecharger.Text;

                MySqlConnection connection = new MySqlConnection("server=localhost;user id=root;persistsecurityinfo=True;database=mobileshop; password = Ab12345678#");
                connection.Open();
                string query = $"INSERT INTO AnotherCategoryItemAdd(Template,Back_Cover,phone_charger) values('{template }','{backcover }','{phonecharger }')";
                MySqlCommand mySqlCommand = new MySqlCommand(query, connection);
                mySqlCommand.ExecuteNonQuery();
                connection.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnrest_Click(object sender, EventArgs e)
        {
            txttemplate.Clear();
            txtbackcover.Clear();
            txtphonecharger.Clear();
        }

        private void btnshow_Click(object sender, EventArgs e)
        {
            MySqlConnection connection = new MySqlConnection("server=localhost;user id=root;persistsecurityinfo=True;database=mobileshop; password = Ab12345678#");
            connection.Open();
            string b = "SELECT *FROM AnotherCategoryItemAdd";
            MySqlCommand c1 = new MySqlCommand(b, connection);
            var reader2 = c1.ExecuteReader();
            DataTable table2 = new DataTable();
            table2.Load(reader2);
            dataGridView3.DataSource = table2;
            connection.Close();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            string customername = txttemplate.Text;
            MySqlConnection connection = new MySqlConnection("server=localhost;user id=root;database=mobileshop; password = Ab12345678#");
            connection.Open();
            string query = "delete from AnotherCategoryItemAdd where Template = '" + txttemplate.Text + "'";
            MySqlCommand cmb = new MySqlCommand(query, connection);
            cmb.ExecuteNonQuery();
            MessageBox.Show("User Successfully Deleted");
            connection.Close();
        }

        private void Add_other_Accessories_Load(object sender, EventArgs e)
        {
            lblcid.Visible = false;
            txtcid.Visible = false;
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            lblcid.Visible = true;
            txtcid.Visible = true;
            string cid = txtcid.Text;
            string template = txttemplate.Text;
            string backcover = txtbackcover.Text;
            string phonecharger = txtphonecharger.Text;
            MySqlConnection connection = new MySqlConnection("server=localhost;user id=root;persistsecurityinfo=True;database=mobileshop; password = Ab12345678#");
            connection.Open();
            string query = "UPDATE anothercategoryitemadd SET Template  = '" + template + "', Back_Cover = '" + backcover + "' ,phone_charger  = '" + phonecharger + "' where nid='" + cid + "'";
            MySqlCommand mySqlCommand = new MySqlCommand(query, connection);
            mySqlCommand.ExecuteNonQuery();
            connection.Close();
        }
    }
 
       

  
}

