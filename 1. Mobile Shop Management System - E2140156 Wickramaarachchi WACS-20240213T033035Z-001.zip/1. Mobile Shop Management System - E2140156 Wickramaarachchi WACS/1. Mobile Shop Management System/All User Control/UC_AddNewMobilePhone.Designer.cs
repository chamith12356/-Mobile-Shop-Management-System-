﻿
namespace _1.Mobile_Shop_Management_System.All_User_Control
{
    partial class UC_AddNewMobilePhone
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_AddNewMobilePhone));
            this.lbladdnewphone = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtcompany = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtModelname = new Guna.UI2.WinForms.Guna2TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbram = new Guna.UI2.WinForms.Guna2ComboBox();
            this.cmbinternal = new Guna.UI2.WinForms.Guna2ComboBox();
            this.lblInternalstorage = new System.Windows.Forms.Label();
            this.lblExternalStorage = new System.Windows.Forms.Label();
            this.cmbdisplay = new Guna.UI2.WinForms.Guna2ComboBox();
            this.lbldispalysize = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbsimtype = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cmbfingerprint = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btnsave = new System.Windows.Forms.Button();
            this.btnRest = new System.Windows.Forms.Button();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.txtprice = new Guna.UI2.WinForms.Guna2TextBox();
            this.lblphonestock = new System.Windows.Forms.Label();
            this.btndelete = new System.Windows.Forms.Button();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btnshow = new System.Windows.Forms.Button();
            this.txtcid = new Guna.UI2.WinForms.Guna2TextBox();
            this.lblcid = new System.Windows.Forms.Label();
            this.txtbattery = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtcam = new Guna.UI2.WinForms.Guna2TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbladdnewphone
            // 
            this.lbladdnewphone.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbladdnewphone.Font = new System.Drawing.Font("Century Gothic", 25.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbladdnewphone.Image = ((System.Drawing.Image)(resources.GetObject("lbladdnewphone.Image")));
            this.lbladdnewphone.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbladdnewphone.Location = new System.Drawing.Point(26, -1);
            this.lbladdnewphone.Name = "lbladdnewphone";
            this.lbladdnewphone.Size = new System.Drawing.Size(709, 64);
            this.lbladdnewphone.TabIndex = 0;
            this.lbladdnewphone.Text = "New Mobile Phone Item Add";
            this.lbladdnewphone.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(22, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Company";
            // 
            // txtcompany
            // 
            this.txtcompany.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtcompany.DefaultText = "";
            this.txtcompany.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtcompany.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtcompany.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtcompany.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtcompany.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtcompany.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcompany.ForeColor = System.Drawing.Color.Black;
            this.txtcompany.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtcompany.Location = new System.Drawing.Point(26, 90);
            this.txtcompany.Margin = new System.Windows.Forms.Padding(4);
            this.txtcompany.Name = "txtcompany";
            this.txtcompany.PasswordChar = '\0';
            this.txtcompany.PlaceholderText = "";
            this.txtcompany.SelectedText = "";
            this.txtcompany.Size = new System.Drawing.Size(395, 46);
            this.txtcompany.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txtcompany.TabIndex = 2;
            // 
            // txtModelname
            // 
            this.txtModelname.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtModelname.DefaultText = "";
            this.txtModelname.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtModelname.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtModelname.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtModelname.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtModelname.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtModelname.Font = new System.Drawing.Font("Segoe UI", 10.2F);
            this.txtModelname.ForeColor = System.Drawing.Color.Black;
            this.txtModelname.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtModelname.Location = new System.Drawing.Point(26, 178);
            this.txtModelname.Margin = new System.Windows.Forms.Padding(4);
            this.txtModelname.Name = "txtModelname";
            this.txtModelname.PasswordChar = '\0';
            this.txtModelname.PlaceholderText = "";
            this.txtModelname.SelectedText = "";
            this.txtModelname.Size = new System.Drawing.Size(395, 46);
            this.txtModelname.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txtModelname.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(22, 150);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "Model Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(22, 241);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 25);
            this.label3.TabIndex = 5;
            this.label3.Text = "Ram";
            // 
            // cmbram
            // 
            this.cmbram.Animated = true;
            this.cmbram.BackColor = System.Drawing.Color.Transparent;
            this.cmbram.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbram.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbram.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbram.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbram.Font = new System.Drawing.Font("Segoe UI", 10.2F);
            this.cmbram.ForeColor = System.Drawing.Color.Black;
            this.cmbram.ItemHeight = 30;
            this.cmbram.Items.AddRange(new object[] {
            "1GB",
            "2GB",
            "4GB",
            "8GB",
            "16GB",
            "32GB"});
            this.cmbram.Location = new System.Drawing.Point(26, 268);
            this.cmbram.Name = "cmbram";
            this.cmbram.Size = new System.Drawing.Size(395, 36);
            this.cmbram.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.cmbram.TabIndex = 6;
            // 
            // cmbinternal
            // 
            this.cmbinternal.Animated = true;
            this.cmbinternal.BackColor = System.Drawing.Color.Transparent;
            this.cmbinternal.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbinternal.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbinternal.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbinternal.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbinternal.Font = new System.Drawing.Font("Segoe UI", 10.2F);
            this.cmbinternal.ForeColor = System.Drawing.Color.Black;
            this.cmbinternal.ItemHeight = 30;
            this.cmbinternal.Items.AddRange(new object[] {
            "4GB",
            "8GB",
            "16GB",
            "32GB",
            "128GB",
            "256GB"});
            this.cmbinternal.Location = new System.Drawing.Point(26, 348);
            this.cmbinternal.Name = "cmbinternal";
            this.cmbinternal.Size = new System.Drawing.Size(395, 36);
            this.cmbinternal.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.cmbinternal.TabIndex = 8;
            // 
            // lblInternalstorage
            // 
            this.lblInternalstorage.AutoSize = true;
            this.lblInternalstorage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInternalstorage.Location = new System.Drawing.Point(22, 321);
            this.lblInternalstorage.Name = "lblInternalstorage";
            this.lblInternalstorage.Size = new System.Drawing.Size(81, 25);
            this.lblInternalstorage.TabIndex = 7;
            this.lblInternalstorage.Text = "Storage";
            // 
            // lblExternalStorage
            // 
            this.lblExternalStorage.AutoSize = true;
            this.lblExternalStorage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExternalStorage.Location = new System.Drawing.Point(22, 404);
            this.lblExternalStorage.Name = "lblExternalStorage";
            this.lblExternalStorage.Size = new System.Drawing.Size(78, 25);
            this.lblExternalStorage.TabIndex = 9;
            this.lblExternalStorage.Text = "Battery ";
            // 
            // cmbdisplay
            // 
            this.cmbdisplay.Animated = true;
            this.cmbdisplay.BackColor = System.Drawing.Color.Transparent;
            this.cmbdisplay.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbdisplay.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbdisplay.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbdisplay.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbdisplay.Font = new System.Drawing.Font("Segoe UI", 10.2F);
            this.cmbdisplay.ForeColor = System.Drawing.Color.Black;
            this.cmbdisplay.ItemHeight = 30;
            this.cmbdisplay.Items.AddRange(new object[] {
            "5.0 inch",
            "5.5 inch",
            "6.0 inch",
            "6.5 inch",
            "7.0 inch"});
            this.cmbdisplay.Location = new System.Drawing.Point(646, 201);
            this.cmbdisplay.Name = "cmbdisplay";
            this.cmbdisplay.Size = new System.Drawing.Size(395, 36);
            this.cmbdisplay.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.cmbdisplay.TabIndex = 12;
            // 
            // lbldispalysize
            // 
            this.lbldispalysize.AutoSize = true;
            this.lbldispalysize.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldispalysize.Location = new System.Drawing.Point(642, 150);
            this.lbldispalysize.Name = "lbldispalysize";
            this.lbldispalysize.Size = new System.Drawing.Size(120, 25);
            this.lbldispalysize.TabIndex = 11;
            this.lbldispalysize.Text = "Display Size";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(22, 575);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(172, 25);
            this.label5.TabIndex = 15;
            this.label5.Text = "Fingerprint Sensor";
            // 
            // cmbsimtype
            // 
            this.cmbsimtype.Animated = true;
            this.cmbsimtype.BackColor = System.Drawing.Color.Transparent;
            this.cmbsimtype.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbsimtype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbsimtype.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbsimtype.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbsimtype.Font = new System.Drawing.Font("Segoe UI", 10.2F);
            this.cmbsimtype.ForeColor = System.Drawing.Color.Black;
            this.cmbsimtype.ItemHeight = 30;
            this.cmbsimtype.Items.AddRange(new object[] {
            "One Sim",
            "Dul Sim",
            "Tripal Sim"});
            this.cmbsimtype.Location = new System.Drawing.Point(26, 521);
            this.cmbsimtype.Name = "cmbsimtype";
            this.cmbsimtype.Size = new System.Drawing.Size(395, 36);
            this.cmbsimtype.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.cmbsimtype.TabIndex = 18;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(22, 494);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 25);
            this.label6.TabIndex = 17;
            this.label6.Text = "Sim Type";
            // 
            // cmbfingerprint
            // 
            this.cmbfingerprint.Animated = true;
            this.cmbfingerprint.BackColor = System.Drawing.Color.Transparent;
            this.cmbfingerprint.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbfingerprint.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbfingerprint.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbfingerprint.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbfingerprint.Font = new System.Drawing.Font("Segoe UI", 10.2F);
            this.cmbfingerprint.ForeColor = System.Drawing.Color.Black;
            this.cmbfingerprint.ItemHeight = 30;
            this.cmbfingerprint.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbfingerprint.Location = new System.Drawing.Point(26, 610);
            this.cmbfingerprint.Name = "cmbfingerprint";
            this.cmbfingerprint.Size = new System.Drawing.Size(395, 36);
            this.cmbfingerprint.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.cmbfingerprint.TabIndex = 20;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(642, 63);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 25);
            this.label7.TabIndex = 19;
            this.label7.Text = " Camera";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(650, 249);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 25);
            this.label8.TabIndex = 21;
            this.label8.Text = "Price";
            // 
            // btnsave
            // 
            this.btnsave.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold);
            this.btnsave.Location = new System.Drawing.Point(1037, 670);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(189, 52);
            this.btnsave.TabIndex = 23;
            this.btnsave.Text = "Add";
            this.btnsave.UseVisualStyleBackColor = true;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // btnRest
            // 
            this.btnRest.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold);
            this.btnRest.Location = new System.Drawing.Point(27, 670);
            this.btnRest.Name = "btnRest";
            this.btnRest.Size = new System.Drawing.Size(189, 52);
            this.btnRest.TabIndex = 24;
            this.btnRest.Text = "Rest";
            this.btnRest.UseVisualStyleBackColor = true;
            this.btnRest.Click += new System.EventHandler(this.btnRest_Click);
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 26;
            this.guna2Elipse1.TargetControl = this;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(646, 379);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(549, 285);
            this.dataGridView1.TabIndex = 25;
            // 
            // txtprice
            // 
            this.txtprice.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtprice.DefaultText = "";
            this.txtprice.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtprice.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtprice.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtprice.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtprice.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtprice.Font = new System.Drawing.Font("Segoe UI", 10.2F);
            this.txtprice.ForeColor = System.Drawing.Color.Black;
            this.txtprice.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtprice.Location = new System.Drawing.Point(646, 277);
            this.txtprice.Margin = new System.Windows.Forms.Padding(4);
            this.txtprice.Name = "txtprice";
            this.txtprice.PasswordChar = '\0';
            this.txtprice.PlaceholderText = "";
            this.txtprice.SelectedText = "";
            this.txtprice.Size = new System.Drawing.Size(395, 46);
            this.txtprice.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txtprice.TabIndex = 26;
            // 
            // lblphonestock
            // 
            this.lblphonestock.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblphonestock.Image = ((System.Drawing.Image)(resources.GetObject("lblphonestock.Image")));
            this.lblphonestock.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblphonestock.Location = new System.Drawing.Point(641, 327);
            this.lblphonestock.Name = "lblphonestock";
            this.lblphonestock.Size = new System.Drawing.Size(241, 49);
            this.lblphonestock.TabIndex = 29;
            this.lblphonestock.Text = "Phone Stock";
            this.lblphonestock.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btndelete
            // 
            this.btndelete.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold);
            this.btndelete.Location = new System.Drawing.Point(647, 670);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(189, 52);
            this.btndelete.TabIndex = 30;
            this.btndelete.Text = "Delete ";
            this.btndelete.UseVisualStyleBackColor = true;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold);
            this.btnupdate.Location = new System.Drawing.Point(842, 670);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(189, 52);
            this.btnupdate.TabIndex = 31;
            this.btnupdate.Text = "Update ";
            this.btnupdate.UseVisualStyleBackColor = true;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // btnshow
            // 
            this.btnshow.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold);
            this.btnshow.Location = new System.Drawing.Point(971, 327);
            this.btnshow.Name = "btnshow";
            this.btnshow.Size = new System.Drawing.Size(214, 48);
            this.btnshow.TabIndex = 34;
            this.btnshow.Text = "Show Stock";
            this.btnshow.UseVisualStyleBackColor = true;
            this.btnshow.Click += new System.EventHandler(this.btnshow_Click);
            // 
            // txtcid
            // 
            this.txtcid.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtcid.DefaultText = "";
            this.txtcid.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtcid.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtcid.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtcid.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtcid.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtcid.Font = new System.Drawing.Font("Segoe UI", 10.2F);
            this.txtcid.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtcid.Location = new System.Drawing.Point(429, 83);
            this.txtcid.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtcid.Name = "txtcid";
            this.txtcid.PasswordChar = '\0';
            this.txtcid.PlaceholderText = "";
            this.txtcid.SelectedText = "";
            this.txtcid.Size = new System.Drawing.Size(60, 53);
            this.txtcid.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txtcid.TabIndex = 40;
            // 
            // lblcid
            // 
            this.lblcid.AutoSize = true;
            this.lblcid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblcid.ForeColor = System.Drawing.Color.Black;
            this.lblcid.Location = new System.Drawing.Point(424, 61);
            this.lblcid.Name = "lblcid";
            this.lblcid.Size = new System.Drawing.Size(83, 25);
            this.lblcid.TabIndex = 39;
            this.lblcid.Text = "Enter id ";
            // 
            // txtbattery
            // 
            this.txtbattery.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbattery.DefaultText = "mAh";
            this.txtbattery.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtbattery.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtbattery.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtbattery.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtbattery.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtbattery.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbattery.ForeColor = System.Drawing.Color.Black;
            this.txtbattery.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtbattery.Location = new System.Drawing.Point(26, 433);
            this.txtbattery.Margin = new System.Windows.Forms.Padding(4);
            this.txtbattery.Name = "txtbattery";
            this.txtbattery.PasswordChar = '\0';
            this.txtbattery.PlaceholderText = "";
            this.txtbattery.SelectedText = "";
            this.txtbattery.Size = new System.Drawing.Size(395, 46);
            this.txtbattery.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txtbattery.TabIndex = 41;
            // 
            // txtcam
            // 
            this.txtcam.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtcam.DefaultText = "";
            this.txtcam.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtcam.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtcam.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtcam.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtcam.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtcam.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcam.ForeColor = System.Drawing.Color.Black;
            this.txtcam.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtcam.Location = new System.Drawing.Point(647, 93);
            this.txtcam.Margin = new System.Windows.Forms.Padding(4);
            this.txtcam.Name = "txtcam";
            this.txtcam.PasswordChar = '\0';
            this.txtcam.PlaceholderText = "";
            this.txtcam.SelectedText = "";
            this.txtcam.Size = new System.Drawing.Size(395, 46);
            this.txtcam.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txtcam.TabIndex = 42;
            // 
            // UC_AddNewMobilePhone
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.txtcam);
            this.Controls.Add(this.txtbattery);
            this.Controls.Add(this.txtcid);
            this.Controls.Add(this.lblcid);
            this.Controls.Add(this.btnshow);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.lblphonestock);
            this.Controls.Add(this.txtprice);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnRest);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.cmbfingerprint);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cmbsimtype);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cmbdisplay);
            this.Controls.Add(this.lbldispalysize);
            this.Controls.Add(this.lblExternalStorage);
            this.Controls.Add(this.cmbinternal);
            this.Controls.Add(this.lblInternalstorage);
            this.Controls.Add(this.cmbram);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtModelname);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtcompany);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbladdnewphone);
            this.Name = "UC_AddNewMobilePhone";
            this.Size = new System.Drawing.Size(1116, 779);
            this.Load += new System.EventHandler(this.UC_AddNewMobilePhone_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbladdnewphone;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2TextBox txtcompany;
        private Guna.UI2.WinForms.Guna2TextBox txtModelname;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2ComboBox cmbram;
        private Guna.UI2.WinForms.Guna2ComboBox cmbinternal;
        private System.Windows.Forms.Label lblInternalstorage;
        private System.Windows.Forms.Label lblExternalStorage;
        private Guna.UI2.WinForms.Guna2ComboBox cmbdisplay;
        private System.Windows.Forms.Label lbldispalysize;
        private System.Windows.Forms.Label label5;
        private Guna.UI2.WinForms.Guna2ComboBox cmbsimtype;
        private System.Windows.Forms.Label label6;
        private Guna.UI2.WinForms.Guna2ComboBox cmbfingerprint;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.Button btnRest;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private Guna.UI2.WinForms.Guna2TextBox txtprice;
        private System.Windows.Forms.Label lblphonestock;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Button btnshow;
        private Guna.UI2.WinForms.Guna2TextBox txtcid;
        private System.Windows.Forms.Label lblcid;
        private Guna.UI2.WinForms.Guna2TextBox txtbattery;
        private Guna.UI2.WinForms.Guna2TextBox txtcam;
    }
}
