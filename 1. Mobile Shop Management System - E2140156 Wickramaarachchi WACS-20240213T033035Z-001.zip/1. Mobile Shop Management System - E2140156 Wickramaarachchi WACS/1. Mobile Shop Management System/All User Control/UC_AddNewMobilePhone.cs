﻿
using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace _1.Mobile_Shop_Management_System.All_User_Control
{
    public partial class UC_AddNewMobilePhone : UserControl
    {
        public UC_AddNewMobilePhone()
        {
            InitializeComponent();
          
        }

        private void btnshow_Click(object sender, EventArgs e)
        {
            try
            {
                MySqlConnection connection = new MySqlConnection("server=localhost;user id=root;persistsecurityinfo=True;database=mobileshop; password = Ab12345678#");
                connection.Open();
                string Query = "SELECT *FROM mobile";
                MySqlCommand cmd = new MySqlCommand(Query, connection);
                var reader = cmd.ExecuteReader();
                DataTable table = new DataTable();
                table.Load(reader);
                dataGridView1.DataSource = table;
                connection.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {

                if (txtcompany.Text != "" && txtModelname.Text != "" && cmbram.Text != "" && cmbinternal.Text != "" && txtbattery.Text != "" &&
                    cmbdisplay.Text != "" && txtcam.Text != "" && cmbfingerprint.Text != "" && cmbsimtype.Text != "" && txtprice.Text != "")
                { 

                    string company = txtcompany.Text;
                    string model = txtModelname.Text;
                    string ram = cmbram.Text;
                    string interna = cmbinternal.Text;
                    string expandable = txtbattery.Text;
                    string dispaly = cmbdisplay.Text;
                    string rear = txtcam.Text;
                    string fingerprint = cmbfingerprint.Text;
                    string sim = cmbsimtype.Text;
                    string price = txtprice.Text;

                    MySqlConnection connection = new MySqlConnection("server=localhost;user id=root;persistsecurityinfo=True;database=mobileshop; password = Ab12345678#");
                    connection.Open();
                    string query = $"INSERT INTO mobile(companyname,modelname,ram ,Storage_,Battery,display,cam,fingerprint,sim,price ) values('{company }','{model }','{ram }','{interna}','{expandable}','{dispaly }','{rear }','{fingerprint }','{sim}','{price }')";
                    MySqlCommand mySqlCommand = new MySqlCommand(query, connection);
                    mySqlCommand.ExecuteNonQuery();
                    connection.Close();
                   
                }
                else
                {
                    MessageBox.Show("Fill All Data ");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnRest_Click(object sender, EventArgs e)
        {
            txtcompany.Clear();
            txtModelname.Clear();
            txtprice.Clear();
            cmbdisplay.SelectedIndex = -1;
            txtbattery.Clear();
            cmbfingerprint.SelectedIndex = -1;
            //cmbfrontcam.SelectedIndex = -1;
            cmbinternal.SelectedIndex = -1;
            cmbram.SelectedIndex = -1;
            txtcam.Clear();
            cmbsimtype.SelectedIndex = -1;

        }

      
        private void btnupdate_Click(object sender, EventArgs e)
        {
            try
            {
                lblcid.Visible = true;
                txtcid.Visible = true;
                string cid = txtcid.Text;
                string company = txtcompany.Text;
                string model = txtModelname.Text;
                string ram = cmbram.Text;
                string interna = cmbinternal.Text;
                string expandable = txtbattery.Text;
                string dispaly = cmbdisplay.Text;
                string rear = txtcam.Text;
                string fingerprint = cmbfingerprint.Text;
                string sim = cmbsimtype.Text;
                string price = txtprice.Text;
                MySqlConnection connection = new MySqlConnection("server=localhost;user id=root;persistsecurityinfo=True;database=mobileshop; password = Ab12345678#");

                connection.Open();
              
                String st = $"UPDATE mobile SET companyname = '" + company + "', modelname = '" + model + "',ram = '" + ram + "',Storage_ = '" + interna + "',Battery = '" + expandable + "',display = '" + dispaly + "',cam = '" + rear + "',fingerprint = '" + fingerprint + "',sim = '" + sim + "', price = '" + price + "'where id='"+ cid + "'";
         
                MySqlCommand mySqlCommand = new MySqlCommand(st, connection);
                mySqlCommand.ExecuteNonQuery();
         
                connection.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            try
            {
                string company = txtcompany.Text;
                MySqlConnection connection = new MySqlConnection("server=localhost;user id=root;database=mobileshop; password = Ab12345678#");
                connection.Open();
                string query = "delete from mobile where companyname = '" + txtcompany.Text + "'";
                MySqlCommand Command = new MySqlCommand(query, connection);
                Command.ExecuteNonQuery();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void UC_AddNewMobilePhone_Load(object sender, EventArgs e)
        {
            lblcid.Visible = false;
            txtcid.Visible = false;
        }

      
    }
}
