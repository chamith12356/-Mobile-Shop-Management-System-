﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.IO;
using System.Windows.Forms;

namespace _1.Mobile_Shop_Management_System.All_User_Control
{
    public partial class UC_CustomerAdd : UserControl
    {
        public UC_CustomerAdd()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtcustomername.Text != "" && txtphonenumber.Text != "" && txtaddress.Text != "" && txtitemname.Text != "" && txtitemname.Text != "")
                {
                    string customername = txtcustomername.Text;
                    string dt = dateTimePicker1.Value.ToString();
                    string phonenumber = txtphonenumber.Text;
                    string eaddress = txtemailaddress.Text;
                    string address = txtaddress.Text;
                    string itemname = txtitemname.Text;
                    int itemno=Convert.ToInt32(txtitemno.Text);
                    int price= Convert.ToInt32(txtprice.Text);
                    int price1 = itemno * price;

                    MySqlConnection connection = new MySqlConnection("server=localhost;user id=root;persistsecurityinfo=True;database=mobileshop; password = Ab12345678#");
                    connection.Open();
                    string query = $"INSERT INTO customerbill(Customer_ ,Date_,Phone_Number ,Email,Address,itemname,price ) values('{customername}','{dt}','{phonenumber}','{eaddress}','{address}','{itemname}','{price1.ToString()}')";
                    MySqlCommand mySqlCommand = new MySqlCommand(query, connection);
                    mySqlCommand.ExecuteNonQuery();
                    connection.Close();
                }
                else
                {
                    MessageBox.Show("Fill All Data ");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtaddress.Clear();
            txtcustomername.Clear();
            txtemailaddress.Clear();
            txtitemname.Clear();
            txtphonenumber.Clear();
            txtprice.Clear();

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                string customername = txtcustomername.Text;
                string dt = dateTimePicker1.Value.ToString();
                string phonenumber = txtphonenumber.Text;
                string eaddress = txtemailaddress.Text;
                string address = txtaddress.Text;
                string itemname = txtitemname.Text;
                int itemno = Convert.ToInt32(txtitemno.Text);
                int price = Convert.ToInt32(txtprice.Text);
                int price1 = itemno * price;

                Document doc = new Document(iTextSharp.text.PageSize.LETTER, 10, 10, 42, 35);
                PdfWriter wri = PdfWriter.GetInstance(doc, new FileStream(@"D:\ICT Project\New folder\New folder\1. Mobile Shop Management System - Copy\PDF/Test.pdf", FileMode.Create));
                doc.Open();
                Paragraph paragraph = new Paragraph("                                                         SAHAN MOBILE SHOP" + "\n\n\n" + "Customer Name       " + "                  " + customername + "\n\n" + "Date                   " + "                   " + "     " + dt + "\n\n" + "Phone Number      " + "                " + "     " + phonenumber
                  + "\n\n" + "Email Address       " + "                     " + eaddress + "\n\n" + "Address         " + "                        " + "     " + address + "\n\n" + "Item Name      " + "                       " + "     " + itemname + "\n\n" + "Price           " + "                    " + "            " + price1);
                doc.Add(paragraph);
                doc.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


    private void btnshow_Click(object sender, EventArgs e)
        { 
            MySqlConnection connection = new MySqlConnection("server=localhost;user id=root;persistsecurityinfo=True;database=mobileshop; password = Ab12345678#");
            connection.Open();
            string a = "SELECT *FROM customerbill";
            MySqlCommand c = new MySqlCommand(a, connection);
            var reader1 = c.ExecuteReader();
            DataTable table1 = new DataTable();
            table1.Load(reader1);
            dgv2.DataSource = table1;
            connection.Close();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            string customername = txtcustomername.Text;
            MySqlConnection connection = new MySqlConnection("server=localhost;user id=root;database=mobileshop; password = Ab12345678#");
            connection.Open();
            string query = "delete from customerbill where Customer_ = '" + txtcustomername.Text + "'";
            MySqlCommand cmb = new MySqlCommand(query, connection);
            cmb.ExecuteNonQuery();
            MessageBox.Show("User Successfully Deleted");
            connection.Close();

        }

        private void btnupdate_Click_1(object sender, EventArgs e)
        { try
            {
                lblcid.Visible = true;
                txtcid.Visible = true;
                string cid = txtcid.Text;
                string customername = txtcustomername.Text;
                string dt = dateTimePicker1.Value.ToString();
                string phonenumber = txtphonenumber.Text;
                string eaddress = txtemailaddress.Text;
                string address = txtaddress.Text;
                string itemname = txtitemname.Text;
                int itemno = Convert.ToInt32(txtitemno.Text);
                int price = Convert.ToInt32(txtprice.Text);
                int price1 = itemno * price;

                MySqlConnection connection = new MySqlConnection("server=localhost;user id=root;persistsecurityinfo=True;database=mobileshop; password = Ab12345678#");
                connection.Open();
                string query = "UPDATE customerbill SET Customer_ = '" + customername + "', Date_ = '" + dt + "' ,Phone_Number = '" + phonenumber + "', Email ='" + eaddress + "',Address = '" + itemname + "' , itemname= '" + itemname + "',price= '" + price1 + "' where cid='" + cid + "'";
                MySqlCommand mySqlCommand = new MySqlCommand(query, connection);
                mySqlCommand.ExecuteNonQuery();
                connection.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void UC_CustomerAdd_Load(object sender, EventArgs e)
        {
            lblcid.Visible = false;
            txtcid.Visible = false;
        }
    }
}
