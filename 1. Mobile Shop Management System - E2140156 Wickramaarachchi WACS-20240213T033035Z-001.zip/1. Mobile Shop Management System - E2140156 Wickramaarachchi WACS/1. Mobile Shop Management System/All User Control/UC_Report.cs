﻿using Microsoft.Reporting.WinForms;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1.Mobile_Shop_Management_System
{
    public partial class UC_Report : UserControl
    {
        public UC_Report()
        {
            InitializeComponent();
        }
        private void btnsearch_Click_1(object sender, EventArgs e)
        {
            MySqlConnection connection = new MySqlConnection("server=localhost;user id=root;persistsecurityinfo=True;database=mobileshop; password = Ab12345678#");
            connection.Open();
            string b = "SELECT *FROM customerbill where itemname like '" + txtsearch.Text + "%'";
            MySqlCommand c1 = new MySqlCommand(b, connection);
            DataSet ds = new DataSet();
            MySqlDataAdapter da = new MySqlDataAdapter(c1);
            da.Fill(ds);
            guna2DataGridView2.DataSource = ds.Tables[0];
            connection.Close();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MySqlConnection connection = new MySqlConnection("server=localhost;user id=root;persistsecurityinfo=True;database=mobileshop; password = Ab12345678#");
            connection.Open();
            string d = "SELECT *FROM customerbill where Date_ like '" + txtdate.Text + "%'";
            MySqlCommand c2 = new MySqlCommand(d, connection);
            DataSet ds1 = new DataSet();
            MySqlDataAdapter da1 = new MySqlDataAdapter(c2);
            da1.Fill(ds1);
            guna2DataGridView2.DataSource = ds1.Tables[0];
            connection.Close();
        }

        private void btnshow_Click(object sender, EventArgs e)
        {
            try
            {
                MySqlConnection connection = new MySqlConnection("server=localhost;user id=root;persistsecurityinfo=True;database=mobileshop; password = Ab12345678#");
                connection.Open();
                string a = "SELECT *FROM customerbill";
                MySqlCommand c = new MySqlCommand(a, connection);
                var reader1 = c.ExecuteReader();
                DataTable table1 = new DataTable();
                table1.Load(reader1);
                guna2DataGridView2.DataSource = table1;
                connection.Close();
            }
            catch { }
        }

      

        private void button2_Click_1(object sender, EventArgs e)
        {
            try
            {
                MySqlConnection connection = new MySqlConnection("server=localhost;user id=root;persistsecurityinfo=True;database=mobileshop; password = Ab12345678#");
                connection.Open();
                MySqlCommand c = new MySqlCommand("select * from  customerbill", connection);
                MySqlDataAdapter s = new MySqlDataAdapter(c);
                DataTable dt = new DataTable();
                s.Fill(dt);

                reportViewer1.LocalReport.DataSources.Clear();
                ReportDataSource source = new ReportDataSource("Dataset1", dt);
                reportViewer1.LocalReport.ReportPath = "Report1.rdlc";
                reportViewer1.LocalReport.DataSources.Add(source);
                reportViewer1.RefreshReport();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
