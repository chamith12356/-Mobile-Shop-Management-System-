﻿namespace _1.Mobile_Shop_Management_System.All_User_Control
{
    internal class chart1
    {
    }
}