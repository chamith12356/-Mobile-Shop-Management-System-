﻿
namespace _1.Mobile_Shop_Management_System
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnExit = new System.Windows.Forms.Button();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.btnMinimized = new Guna.UI2.WinForms.Guna2Button();
            this.butonreport = new Guna.UI2.WinForms.Guna2Button();
            this.btncategory = new Guna.UI2.WinForms.Guna2Button();
            this.btncustomer = new Guna.UI2.WinForms.Guna2Button();
            this.btnAddnewphone = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.uC_Report1 = new _1.Mobile_Shop_Management_System.UC_Report();
            this.add_other_Accessories1 = new _1.Mobile_Shop_Management_System.All_User_Control.Add_other_Accessories();
            this.uC_CustomerAdd1 = new _1.Mobile_Shop_Management_System.All_User_Control.UC_CustomerAdd();
            this.uC_AddNewMobilePhone1 = new _1.Mobile_Shop_Management_System.All_User_Control.UC_AddNewMobilePhone();
            this.guna2Elipse16 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Panel1.SuspendLayout();
            this.guna2Panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnExit
            // 
            this.btnExit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnExit.BackgroundImage")));
            this.btnExit.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.Red;
            this.btnExit.Location = new System.Drawing.Point(3, 3);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(50, 49);
            this.btnExit.TabIndex = 0;
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.guna2Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(221)))));
            this.guna2Panel1.Controls.Add(this.btnMinimized);
            this.guna2Panel1.Controls.Add(this.btnExit);
            this.guna2Panel1.Controls.Add(this.butonreport);
            this.guna2Panel1.Controls.Add(this.btncategory);
            this.guna2Panel1.Controls.Add(this.btncustomer);
            this.guna2Panel1.Controls.Add(this.btnAddnewphone);
            this.guna2Panel1.Location = new System.Drawing.Point(25, 13);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Size = new System.Drawing.Size(305, 1852);
            this.guna2Panel1.TabIndex = 1;
            // 
            // btnMinimized
            // 
            this.btnMinimized.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMinimized.BackgroundImage")));
            this.btnMinimized.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnMinimized.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnMinimized.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnMinimized.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnMinimized.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(221)))));
            this.btnMinimized.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnMinimized.ForeColor = System.Drawing.Color.White;
            this.btnMinimized.Image = ((System.Drawing.Image)(resources.GetObject("btnMinimized.Image")));
            this.btnMinimized.ImageSize = new System.Drawing.Size(40, 40);
            this.btnMinimized.Location = new System.Drawing.Point(59, 3);
            this.btnMinimized.Name = "btnMinimized";
            this.btnMinimized.Size = new System.Drawing.Size(53, 49);
            this.btnMinimized.TabIndex = 5;
            this.btnMinimized.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // butonreport
            // 
            this.butonreport.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(221)))));
            this.butonreport.BorderRadius = 30;
            this.butonreport.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.butonreport.CheckedState.BorderColor = System.Drawing.Color.White;
            this.butonreport.CheckedState.FillColor = System.Drawing.Color.White;
            this.butonreport.CheckedState.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.butonreport.FillColor = System.Drawing.Color.Blue;
            this.butonreport.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butonreport.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.butonreport.Location = new System.Drawing.Point(13, 386);
            this.butonreport.Name = "butonreport";
            this.butonreport.Size = new System.Drawing.Size(277, 61);
            this.butonreport.TabIndex = 3;
            this.butonreport.Text = "REPORT AND RECODES";
            this.butonreport.Click += new System.EventHandler(this.guna2Button3_Click);
            // 
            // btncategory
            // 
            this.btncategory.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(221)))));
            this.btncategory.BorderRadius = 30;
            this.btncategory.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btncategory.CheckedState.BorderColor = System.Drawing.Color.White;
            this.btncategory.CheckedState.FillColor = System.Drawing.Color.White;
            this.btncategory.CheckedState.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.btncategory.FillColor = System.Drawing.Color.Blue;
            this.btncategory.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncategory.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btncategory.Location = new System.Drawing.Point(13, 215);
            this.btncategory.Name = "btncategory";
            this.btncategory.Size = new System.Drawing.Size(277, 61);
            this.btncategory.TabIndex = 2;
            this.btncategory.Text = "CATEGORY MANAGEMENT";
            this.btncategory.Click += new System.EventHandler(this.btnitems_Click);
            // 
            // btncustomer
            // 
            this.btncustomer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(221)))));
            this.btncustomer.BorderRadius = 30;
            this.btncustomer.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btncustomer.CheckedState.BorderColor = System.Drawing.Color.White;
            this.btncustomer.CheckedState.FillColor = System.Drawing.Color.White;
            this.btncustomer.CheckedState.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.btncustomer.FillColor = System.Drawing.Color.Blue;
            this.btncustomer.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncustomer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btncustomer.Location = new System.Drawing.Point(13, 300);
            this.btncustomer.Name = "btncustomer";
            this.btncustomer.Size = new System.Drawing.Size(277, 61);
            this.btncustomer.TabIndex = 1;
            this.btncustomer.Text = "CUSTOMER Bill PREPARATION ";
            this.btncustomer.Click += new System.EventHandler(this.btncustomer_Click);
            // 
            // btnAddnewphone
            // 
            this.btnAddnewphone.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(221)))));
            this.btnAddnewphone.BorderRadius = 30;
            this.btnAddnewphone.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnAddnewphone.CheckedState.BorderColor = System.Drawing.Color.White;
            this.btnAddnewphone.CheckedState.FillColor = System.Drawing.Color.White;
            this.btnAddnewphone.CheckedState.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAddnewphone.FillColor = System.Drawing.Color.Blue;
            this.btnAddnewphone.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddnewphone.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnAddnewphone.Location = new System.Drawing.Point(15, 127);
            this.btnAddnewphone.Name = "btnAddnewphone";
            this.btnAddnewphone.Size = new System.Drawing.Size(277, 61);
            this.btnAddnewphone.TabIndex = 0;
            this.btnAddnewphone.Text = "ADD NEW PHONE ITEMS";
            this.btnAddnewphone.Click += new System.EventHandler(this.btnAddnewphone_Click);
            // 
            // guna2Panel2
            // 
            this.guna2Panel2.Controls.Add(this.uC_Report1);
            this.guna2Panel2.Controls.Add(this.add_other_Accessories1);
            this.guna2Panel2.Controls.Add(this.uC_CustomerAdd1);
            this.guna2Panel2.Controls.Add(this.uC_AddNewMobilePhone1);
            this.guna2Panel2.Location = new System.Drawing.Point(316, 3);
            this.guna2Panel2.Name = "guna2Panel2";
            this.guna2Panel2.Size = new System.Drawing.Size(1360, 1060);
            this.guna2Panel2.TabIndex = 2;
            // 
            // uC_Report1
            // 
            this.uC_Report1.BackColor = System.Drawing.Color.White;
            this.uC_Report1.Location = new System.Drawing.Point(0, 3);
            this.uC_Report1.Margin = new System.Windows.Forms.Padding(4);
            this.uC_Report1.Name = "uC_Report1";
            this.uC_Report1.Size = new System.Drawing.Size(1360, 1036);
            this.uC_Report1.TabIndex = 3;
            // 
            // add_other_Accessories1
            // 
            this.add_other_Accessories1.BackColor = System.Drawing.Color.White;
            this.add_other_Accessories1.Location = new System.Drawing.Point(0, 0);
            this.add_other_Accessories1.Margin = new System.Windows.Forms.Padding(4);
            this.add_other_Accessories1.Name = "add_other_Accessories1";
            this.add_other_Accessories1.Size = new System.Drawing.Size(1356, 1039);
            this.add_other_Accessories1.TabIndex = 2;
            // 
            // uC_CustomerAdd1
            // 
            this.uC_CustomerAdd1.BackColor = System.Drawing.Color.White;
            this.uC_CustomerAdd1.Location = new System.Drawing.Point(0, 3);
            this.uC_CustomerAdd1.Name = "uC_CustomerAdd1";
            this.uC_CustomerAdd1.Size = new System.Drawing.Size(1339, 929);
            this.uC_CustomerAdd1.TabIndex = 1;
            // 
            // uC_AddNewMobilePhone1
            // 
            this.uC_AddNewMobilePhone1.BackColor = System.Drawing.Color.White;
            this.uC_AddNewMobilePhone1.Location = new System.Drawing.Point(0, 0);
            this.uC_AddNewMobilePhone1.Margin = new System.Windows.Forms.Padding(4);
            this.uC_AddNewMobilePhone1.Name = "uC_AddNewMobilePhone1";
            this.uC_AddNewMobilePhone1.Size = new System.Drawing.Size(1356, 1039);
            this.uC_AddNewMobilePhone1.TabIndex = 0;
            // 
            // guna2Elipse16
            // 
            this.guna2Elipse16.BorderRadius = 30;
            this.guna2Elipse16.TargetControl = this;
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 26;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(118)))), ((int)(((byte)(221)))));
            this.ClientSize = new System.Drawing.Size(1760, 1055);
            this.Controls.Add(this.guna2Panel2);
            this.Controls.Add(this.guna2Panel1);
            this.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.guna2Panel1.ResumeLayout(false);
            this.guna2Panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnExit;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2Button btnAddnewphone;
        private Guna.UI2.WinForms.Guna2Button butonreport;
        private Guna.UI2.WinForms.Guna2Button btncategory;
        private Guna.UI2.WinForms.Guna2Button btncustomer;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private Guna.UI2.WinForms.Guna2Button btnMinimized;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse16;
        private All_User_Control.Add_other_Accessories add_other_Accessories1;
        private All_User_Control.UC_CustomerAdd uC_CustomerAdd1;
        private All_User_Control.UC_AddNewMobilePhone uC_AddNewMobilePhone1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private UC_Report uC_Report1;
    }
}

