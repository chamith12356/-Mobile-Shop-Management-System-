﻿using System;
using System.Windows.Forms;

namespace _1.Mobile_Shop_Management_System
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            uC_AddNewMobilePhone1.Visible = false;
            uC_CustomerAdd1.Visible = false;
            add_other_Accessories1.Visible = false;
            uC_Report1.Visible = false;
        }

        private void btnAddnewphone_Click(object sender, EventArgs e)
        {
            uC_AddNewMobilePhone1.Visible = true;
            uC_AddNewMobilePhone1.BringToFront();
            

        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btncustomer_Click(object sender, EventArgs e)
        {
            uC_AddNewMobilePhone1.Visible = false;
            uC_CustomerAdd1.Visible = true;
            uC_CustomerAdd1.BringToFront();
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            uC_Report1.Visible = true;
            uC_Report1.BringToFront();
        }

        private void btnitems_Click(object sender, EventArgs e)
        {
            uC_CustomerAdd1.Visible = false;
            add_other_Accessories1.Visible = true;
            add_other_Accessories1.BringToFront();
        }
    }
}
