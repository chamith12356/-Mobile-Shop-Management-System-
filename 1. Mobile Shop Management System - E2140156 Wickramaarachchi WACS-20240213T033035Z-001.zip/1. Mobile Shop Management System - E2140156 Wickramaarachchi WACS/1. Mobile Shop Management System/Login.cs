﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace _1.Mobile_Shop_Management_System
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string username = txtusername.Text;
                string password = txtpassword.Text;

               
                 if (txtusername.Text == "abc" && txtpassword.Text == "abc123")
                {
                    MessageBox.Show("Login successful ");
                    Form1 frm = new Form1();
                    frm.Show();

                    Staff_Registration s = new Staff_Registration();
                    s.Show();

                }
                else if (txtusername.Text == "cashier" && txtpassword.Text == "1234")
                {
                    MessageBox.Show("Login successful ");// Login successful message
                    Form1 frm = new Form1();// open new Form
                    frm.Show();

                }
                else if (txtusername.Text == "Salesman" && txtpassword.Text == "456")
                {
                    MessageBox.Show("Login successful ");// Login successful message
                    Form1 frm = new Form1();// open new Form
                    frm.Show();
                }

                else
                {
                    MessageBox.Show("Enter Correct Username And Password ");
                }
              
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnrest_Click(object sender, EventArgs e)
        {
            txtpassword.Clear();
            txtusername.Clear();
        }
    }
}
