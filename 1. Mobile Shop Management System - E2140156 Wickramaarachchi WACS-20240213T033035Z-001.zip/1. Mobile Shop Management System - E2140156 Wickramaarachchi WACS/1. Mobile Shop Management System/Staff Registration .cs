﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace _1.Mobile_Shop_Management_System
{
    public partial class Staff_Registration : Form
    {
        public Staff_Registration()
        {
            InitializeComponent();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            try
            {
                string no = txtno.Text;
                string fname = txtFirstname.Text;
                string lname = txtLastname.Text;
                String mobile = txtmobile.Text;
                string userName = txtUsername.Text;
                string pasword = txtPassword.Text;

                MySqlConnection connection = new MySqlConnection("server=localhost;user id=root;database=mobileshop; password = Ab12345678#");
                connection.Open();
                string query = $"INSERT INTO Staff_Registration(Num,First_Name,Last_Name ,mobile,User_Name,passwordno) values('{no }','{fname }','{lname }','{mobile}','{userName}','{pasword}')";
                MySqlCommand mySqlCommand = new MySqlCommand(query, connection);
                mySqlCommand.ExecuteNonQuery();
               
                string Query = "SELECT *FROM staff_registration";
                MySqlCommand cmd = new MySqlCommand(Query, connection);
                var reader = cmd.ExecuteReader();
                DataTable table = new DataTable();
                table.Load(reader);
                dataGridView1staff.DataSource = table;
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Staff_Registration_Load(object sender, EventArgs e)
        {
            MySqlConnection connection = new MySqlConnection("server=localhost;user id=root;database=mobileshop; password = Ab12345678#");
            connection.Open();
            string Query = "SELECT *FROM staff_registration";
            MySqlCommand cmd = new MySqlCommand(Query, connection);
            var reader = cmd.ExecuteReader();
            DataTable table = new DataTable();
            table.Load(reader);
            dataGridView1staff.DataSource = table;
            connection.Close();

        }

        private void btnClear_Click_1(object sender, EventArgs e)
        {
            txtFirstname.Clear();
            txtLastname.Clear();
            txtmobile.Clear();
            txtno.Clear();
            txtPassword.Clear();
            txtUsername.Clear();
        }
    }
}
