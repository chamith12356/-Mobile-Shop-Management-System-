create database mobileshop;

create table mobile(
id int NOT NULL AUTO_INCREMENT,
companyname varchar(250) ,
modelname varchar(250) ,
ram varchar(250) ,
Storage_ varchar(250) ,
Battery varchar(250) ,
sim varchar(250),
fingerprint varchar(250) ,
cam varchar(250) ,
display varchar(250) ,
price int ,
PRIMARY KEY (id)
);

create table customerbill(
cid int NOT NULL AUTO_INCREMENT,
Customer_ varchar(250),
Date_ varchar(250),
Phone_Number int,
Email varchar(250),
Address varchar(250),
itemname varchar(250),
price varchar(250),
PRIMARY KEY (cid)
);


create table staff_Registration(
Num int,
First_Name varchar(250),
Last_Name varchar(250),
User_Name varchar(15),
mobile int,
passwordno varchar(15),
primary key(Num));

create table AnotherCategoryItemAdd  (
nid int NOT NULL AUTO_INCREMENT,
Template  varchar(250),
Back_Cover varchar(250),
phone_charger  varchar(250),
primary key(nid)
);






